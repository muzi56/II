# 末日危机2（Click Pocalypse 2）

汉化版：https://likexia.gitee.io/clickpocalypse2

英文版：http://minmaxia.com/c2/